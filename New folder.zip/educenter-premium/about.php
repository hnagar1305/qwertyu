<!DOCTYPE html>
<html lang="en">
  <head>
      <link id="theme-color-file" href="css/color-themes/default-theme.css" rel="stylesheet">
      <link href="css/color-switcher-design.css" rel="stylesheet">

    <link
      href="https://fonts.googleapis.com/css?family=Open+Sans"
      rel="stylesheet"
    />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
    <link rel="stylesheet" href="css/bootstrap.css" />
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    <link rel="stylesheet" href="fonts/ionicons/css/ionicons.min.css">
    <link rel="stylesheet" href="fonts/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

    <script src="js/bootstrap.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/jquery.js"></script>
    <script src="css/font.css"></script>
    <script
      defer
      src="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"
    ></script>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <link rel="stylesheet" href="css/custom.css" />
<link rel='stylesheet' id='compiled.css-css'  href='https://mdbootstrap.com/wp-content/themes/mdbootstrap4/css/compiled-4.8.2.min.css?ver=4.8.2' type='text/css' media='all' />
</script>
    <link rel='dns-prefetch' href='//chimpstatic.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
    <title>About</title>
  </head>
  <body>
<br>
    <nav class="navbar fixed-top navbar-expand-md navbar-dark bg-dark">
      <a class="navbar-brand" href="#">DOCTOR</a>

      <button
        class="navbar-toggler"
        type="button"
        data-toggle="collapse"
        data-target=".navbar-collapse"
        aria-expanded="true"
      >
        <span class="navbar-toggler-icon">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mx-auto">
          <li class="nav-item">
            <a class="nav-link active" href="Home.html">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="educenter-premium/about.html">About</a>
          </li>


        <li class="nav-item">
          <a class="nav-link active" href="file:///C:/Users/Himanshu%20Nagar/Desktop/Preeti%20Homeopathy/conat.html">Contact</a>
        </li>
        </ul>

        <div class="btn-outer">
            <a href="#" class="btn blue-gradient btn btn-rounded" data-toggle="modal" data-target="#modalAppointment">Book Appointment</a></button>
          </div>
      </div>
    </nav>
    <br>
<section class="page-title-section overlay" data-background="images/4321.jpg" style="background-image: url(&quot;images/4321.jpg&quot;);">
<div class="container">
      <div class="row">
        <div class="col-12" style="height:400px;"><h1 position="absolute" align="center" style="font-size:5em; padding:150px;">ABOUT</h1>
        </div>
      </div>
    </div>
  </section>
  <br>
<section class="section bg-cover" data-background="images/1234.jpg" style="background-image: url(&quot;images/1234.jpg&quot;);">
  <div class="container">
    <div class="row">
      <div class="col-lg-6 col-sm-4 position-relative success-video">
        <a class="play-btn venobox vbox-item" href="https://youtu.be/nA1Aqp0sPQo" data-vbtype="video">
          <i class="ti-control-play"></i>
        </a>
      </div>
      <div class="col-lg-6 col-sm-8">
        <div class="bg-white p-5">
          <h2 class="section-title">Success Stories</h2>
          <p>Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text .</p>
          <p>Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text.</p>
          <p>Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text </p>
        </div>
      </div>
    </div>
  </div>
</section>



<footer class="page-footer font-small special-color-dark pt-4">
    <div class="footer bg-footer section border-bottom">
      <div class="container">

        <div class="row">
          <div class="col-lg-4 col-sm-8 mb-5 mb-lg-0">
            <!-- logo -->
            <ul class="list-unstyled">
              <br>
              <h1>       Contact </h1>
              <li class="mb-2">BANGALURU,ANDRA PRADESH</li>
              <li class="mb-2">+91 8800599487</li>
              <li class="mb-2">+91 8979922610</li>
              <li class="mb-2">contact@preetihomeopathy.com</li>
            </ul>

          <!-- Grid column -->

        </div>
      </div>

    </div>
  </div>
</div>
<footer class="page-footer font-small special-color-dark pt-4">
<div class="container">
<h1 style="text-align: center;">Follow Me On Social Media...</h1>
<!-- Grid row-->
<div class="row">
    <div class="col-md-12 py-5">
<div class="mb-5 flex-center">


  <!-- Facebook -->
  <a class="fb-ic">
    <i class="fab fa-facebook-f fa-lg white-text mr-md-5 mr-3 fa-2x" aria-hidden="true"></i>
  </a>
  <!-- Twitter -->
  <a class="tw-ic">
    <i class="fab fa-twitter fa-lg white-text mr-md-5 mr-3 fa-2x" aria-hidden="true"> </i>
  </a>
  <!--Linkedin -->
  <a class="li-ic">
    <i class="fab fa-linkedin-in fa-lg white-text mr-md-5 mr-3 fa-2x" aria-hidden="true"> </i>
  </a>
  <!--Instagram-->
  <a class="ins-ic">
    <i class="fab fa-instagram fa-lg white-text mr-md-5 mr-3 fa-2x" aria-hidden="true"> </i>
  </a>
</div>
</div>
<!-- Grid column -->

</div>
<!-- Grid row-->

</div>

    <!-- copyright -->
     <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2019 Copyright: Preeti Homeopathy<br><br>Designed By:<a href="https://www.facebook.com/himanshu.choco"> Himanshu Nagar </a><br><p>Phone No. 8979922610</p>
  </div>
  <!-- Copyright -->
  </footer>
        <link
        href="https://fonts.googleapis.com/css?family=Open+Sans"
        rel="stylesheet"
      />
      <link rel="stylesheet" href="css/bootstrap.css" />
      <script>
        var map;
        function initMap() {
          map = new google.maps.Map(document.getElementById('map'), {
            center: {lat: 27.202261373594386, lng: -77.95265911905742},
            zoom: 8
          });
        }
      </script async defer></script>
      <script src="js/jquery.fancybox.pack.js"></script>
      <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAwGUSnH2EpjrptUBcc473sdpjCghkuLu8&callback=initMap"
  <script src="js/jquery.fancybox-media.js"></script>
  <script src="js/owl.js"></script>
  <script src="js/wow.js"></script>
  <script src="js/appear.js"></script>
  <script src="js/color-settings.js"></script>
  <script src="js/jquery-3.2.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/main.js"></script>
        <defer
        src="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"
        <script src="js/popper.js"></script>
      </script>
      <script>
      const element =  document.querySelector('.my-element')
  element.classList.add('animated', 'bounceOutLeft')
  </script>
  </body>
  </html>
