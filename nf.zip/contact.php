<?php
if (isset($_POST['submit'])){
  $name = $_POST['name'];
  $email = $_POST['email'];
  $date = $_POST['date'];
  $time = $_POST['time'];
  $message = $_POST['message'];

  $mailTo = "negebofa@imaild.com";
  $headers= "From: ".$mailFrom;
  $txt = "You have recieved Email from ".$name.".\n\n".$message;

  mail($mailTo,$date,$time,$txt,$headers)
  header("Location: home.php?mailsend"


}
?>
