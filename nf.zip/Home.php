<!DOCTYPE html>
<html lang="en">
  <head>  <link id="theme-color-file" href="css/color-themes/default-theme.css" rel="stylesheet">
    <link href="css/color-switcher-design.css" rel="stylesheet">

  <link
    href="https://fonts.googleapis.com/css?family=Open+Sans"
    rel="stylesheet"
  />
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="css/animate.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/bootstrap-datepicker.css">
  <link rel="stylesheet" href="css/jquery.timepicker.css">
  <link rel="stylesheet" href="fonts/ionicons/css/ionicons.min.css">
  <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
  <script src="js/bootstrap.js"></script>
  <script src="js/popper.js"></script>
  <script src="js/jquery.js"></script>
  <script src="css/font.css"></script>
  <script
    defer
    src="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"
  ></script>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="X-UA-Compatible" content="ie=edge" />
  <link rel="stylesheet" href="css/custom.css" />
<link rel='stylesheet' id='compiled.css-css'  href='https://mdbootstrap.com/wp-content/themes/mdbootstrap4/css/compiled-4.8.2.min.css?ver=4.8.2' type='text/css' media='all' />
</script>
  <link rel='dns-prefetch' href='//chimpstatic.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.min.css">
  <title>Home</title>
  </head>
  <body>
    <!--NAV START-->

    <nav class="navbar fixed-top navbar-expand-md navbar-dark bg-dark">
      <a class="navbar-brand" href="#">DOCTOR</a>
      <button
        class="navbar-toggler"
        type="button"
        data-toggle="collapse"
        data-target=".navbar-collapse"
        aria-expanded="true"
      >
        <span class="navbar-toggler-icon">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mx-auto">
          <li class="nav-item">
            <a class="nav-link active" href="Home.html">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="educenter-premium/about.html">About</a>
          </li>
        <li class="nav-item">
          <a class="nav-link active" href="file:///C:/Users/Himanshu%20Nagar/Desktop/Preeti%20Homeopathy/conat.html">Contact</a>
        </li>
        </ul>

        <div class="btn-outer">
            <a href="#" class="btn blue-gradient btn btn-rounded" data-toggle="modal" data-target="#modalAppointment">Book Appointment</a></button>
          </div>
      </div>
    </nav>
    <br>
    <br>
    <!--NAV TERMINATION-->
    <!--main wallpaper-->
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
          <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
          <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="img/image (6).jpg" class="d-block w-100" style="height: auto;" alt="MESSI" >
            <div class="carousel-caption" style="top:30%; left:-20%;">
              <h1 class="animated fadeInDown delay-1s" position="absolute" top="40px" style="font-size:4em;">HOMEOPATHY EXPERT</h1>
              <h3>Practicing from past 4 years!</h3>
            </div>
          </div>
          <div class="carousel-item">
            <img src="img/image (7).jpg" class="d-block w-100" style="height: auto;" alt="MESSI">
            <div class="carousel-caption" style="top:30%; left:-20%;">
              <h1 class="animated fadeInLeft delay-1s" position="absolute" top="40px" style="font-size:4em;">CARE FOR LIFE</h1>
              <h3>Leading The Way In Medical Excellence!</h3>
            </div>
          </div>
          <div class="carousel-item">
            <img src="img/image (8).jpg" class="d-block w-100" style="height: auto;" alt="MESSI">
            <div class="carousel-caption" style="top:30%; left:-15%;">
              <h1 class="animated fadeInUp delay-1s" position="absolute" top="40px" style="font-size:4em;">TREAT PATIENT NOT DISEASE</h1>
              <h3>Believe In What's Best For Us!</h3>
            </div>
          </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>
      <script src="js/bootstrap.js"></script>
      <script src="js/popper.js"></script>
      <script src="js/jquery.js.js"></script>
      <hr>
    <!-- Section: Testimonials v.1 -->
    <div>
    <a href="#" class="btn btn-rounded btn-primary btn-lg btn-block"  data-toggle="modal" data-target="#modalAppointment">Book appointment</button>
    </a>
    </div>
<hr>
  <div  class="col-md-10 mb-40">
  <div class="avatar mx-auto mb-7" style="float:left;">
      <img src="img/H1.jpg" class="rounded-circle img-fluid" style="height:250px; widows: 250px;" alt="Samuel Hannemann">
    </div>

    <p>
       <br>
       <h3 style="left:100px;">Dr. Samuel Hahnemann</h3>
       <hr style="line-height: 500px;">
      <i class="fas fa-quote-left"></i>  Changes that come to material substances, specially the medicinal, through the trituration of non-medicinal powder, agitation of non-medicinal fluid, are so incredible that may be compared to miracles, and is a reason of joy that those changes belong to Homeopathy.
      <i class="fas fa-quote-right"></i>
      </p>

  </div>
  <br>
</div>
    <!-- Section: Testimonials v.1 -->
    <section class="text-center my-3 p-4">
      <!-- Section heading -->
      <h2 class="h1-responsive" style="font-family: Helvetica;">What <b>Our People </b>Say</h2>
      <!-- Section description -->
      <p class="dark-grey-text w-responsive mx-auto mb-5">
      </p>
      <!-- Grid row -->
      <div class="row">
        <!--Grid column-->
        <div class="col-lg-4 col-md-12 mb-lg-0 mb-4">
          <!--Card-->
          <div class="card testimonial-card">
            <!--Background color-->
            <div class="card-up info-color"></div>
            <!--Avatar-->
            <div class="avatar mx-auto white">
              <img
                src="img/IMG_5768.jpg"
                class="rounded-circle img-fluid"
              />
            </div>
            <div class="card-body">
              <!--Name-->
              <h4 class="font-weight-bold mb-4">Himanshu Nagar</h4>
              <hr />
              <!--Quotation-->
              <p class="dark-grey-text mt-4">
                <i class="fas fa-quote-left pr-2"></i>My experience with the Doctor is Amazing.<i class="fas fa-quote-right pr-2"></i>
              </p>
            </div>
          </div>
          <!--Card-->
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-lg-4 col-md-6 mb-md-0 mb-4">
          <!--Card-->
          <div class="card testimonial-card">
            <!--Background color-->
            <div class="card-up blue-gradient"></div>
            <!--Avatar-->
            <div class="avatar mx-auto white">
              <img
                src="img/ZACK.jpg"
                class="rounded-circle img-fluid"
              />
            </div>
            <div class="card-body">
              <!--Name-->
              <h4 class="font-weight-bold mb-4">Clay Jensen</h4>
              <hr />
              <!--Quotation-->
              <p class="dark-grey-text mt-4">
                <i class="fas fa-quote-left pr-2"></i>One of the best Doctor around.<i class="fas fa-quote-right pr-2"></i>
              </p>
            </div>
          </div>
          <!--Card-->
        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-lg-4 col-md-6">
          <!--Card-->
          <div class="card testimonial-card">
            <!--Background color-->
            <div class="card-up indigo"></div>
            <!--Avatar-->
            <div class="avatar mx-auto white">
              <img
                src="img/MESSI.jpg"
                class="rounded-circle img-fluid"
              />
            </div>
            <div class="card-body">
              <!--Name-->
              <h4 class="font-weight-bold mb-4">Lionel Messi</h4>
              <hr />
              <!--Quotation-->
              <p class="dark-grey-text mt-4">
                <i class="fas fa-quote-left pr-2"></i>The way doctor take a case is best.<i class="fas fa-quote-right pr-2"></i>
              </p>
            </div>
          </div>
          <!--Card-->
        </div>
        <!--Grid column-->
      </div>
      <!-- Grid row -->
    </section>

    <br>
    <h1  align="center" style="font-size:4em;">Our Services</h1>
<hr style="height:2px; background:#000000;">
    <section class="container home-feature mb-5">
         <div class="row">
           <div class="col-md-4 p-0 one-col">
             <div class="col-inner p-xl-5 p-lg-5 p-md-4 p-sm-4 p-4">
               <span class="icon flaticon-hospital-bed"></span>
               <h2>Patient Services</h2>
               <p>Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text .</p>
             </div>
             </div>
           <div class="col-md-4 p-0 two-col">
             <div class="col-inner p-xl-5 p-lg-5 p-md-4 p-sm-4 p-4">
               <span class="icon flaticon-first-aid-kit"></span>
               <h2>Medical Services</h2>
               <p>Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text .</p>
             </div>
             </div>
           <div class="col-md-4 p-0 three-col">
             <div class="col-inner p-xl-5 p-lg-5 p-md-4 p-sm-4 p-4">
               <span class="icon flaticon-hospital"></span>
               <h2>Low Cost</h2>
               <p>Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text Text.</p>
             </div>
             </div>
         </div>
       </section>

      <!--MAP-->

`    <div class="map">
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d22864.11283411948!2d-73.96468908098944!3d40.630720240038435!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew+York%2C+NY%2C+USA!5e0!3m2!1sen!2sbg!4v1540447494452" width="100%" height="380" frameborder="0" style="border:0" allowfullscreen=""></iframe>
    </div>


    <!--FOOTER-->
      <!-- Footer -->
      <footer class="page-footer font-small special-color-dark pt-4">

  <!-- Footer Elements -->
  <div class="container">
<h1 style="text-align: center;">Follow Me On Social Media...</h1>
    <!-- Grid row-->
    <div class="row">
            <div class="col-md-12 py-5">
        <div class="mb-5 flex-center">


          <!-- Facebook -->
          <a class="fb-ic">
            <i class="fab fa-facebook-f fa-lg white-text mr-md-5 mr-3 fa-2x" aria-hidden="true"></i>
          </a>
          <!-- Twitter -->
          <a class="tw-ic">
            <i class="fab fa-twitter fa-lg white-text mr-md-5 mr-3 fa-2x" aria-hidden="true"> </i>
          </a>
          <!--Linkedin -->
          <a class="li-ic">
            <i class="fab fa-linkedin-in fa-lg white-text mr-md-5 mr-3 fa-2x" aria-hidden="true"> </i>
          </a>
          <!--Instagram-->
          <a class="ins-ic">
            <i class="fab fa-instagram fa-lg white-text mr-md-5 mr-3 fa-2x" aria-hidden="true"> </i>
          </a>
        </div>
      </div>
      <!-- Grid column -->

    </div>
    <!-- Grid row-->

  </div>
  <!-- Footer Elements -->

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2019 Copyright: Preeti Homeopathy<br><br>Designed By:<a href="https://www.facebook.com/himanshu.choco"> Himanshu Nagar </a><br><p>Phone No. 8979922610</p>
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->

<div class="modal fade" id="modalAppointment" tabindex="-1" role="dialog" aria-labelledby="modalAppointmentLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalAppointmentLabel">Appointment</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form action="contact.php">
          <div class="form-group">
            <label for="appointment_name" class="text-black">Full Name</label>
            <input type="text" class="form-control" name="name" id="appointment_name">
          </div>
          <div class="form-group">
            <label for="appointment_email" class="text-black">Email</label>
            <input type="text" class="form-control" name="email" id="appointment_email">
          </div>
          <div class="row">
            <div class="col-md-6">
              <div class="form-group">
                <label for="appointment_date" class="text-black">Date</label>
                <input type="text" class="form-control" name="date" id="appointment_date">
              </div>
            </div>
            <div class="col-md-6">
              <div class="form-group">
                <label for="appointment_time" class="text-black">Time</label>
                <input type="text" class="form-control" name="time" id="appointment_time">
              </div>
            </div>
          </div>

          <div class="form-group">
            <label for="appointment_message" class="text-black">Message</label>
            <textarea name="" id="appointment_message" name="message" class="form-control" cols="30" rows="5"></textarea>
          </div>
          <div class="form-group">
            <input type="submit" name="submit" value="Send Message" class="btn btn-primary btn-rounded">
          </div>
        </form>
      </div>

    </div>
  </div>
</div>




    <link
      href="https://fonts.googleapis.com/css?family=Open+Sans"
      rel="stylesheet"
    />
    <link rel="stylesheet" href="css/bootstrap.css" />
    <script>
      var map;
      function initMap() {
        map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: 27.202261373594386, lng: -77.95265911905742},
          zoom: 8
        });
      }
    </script>
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/bootstrap-datepicker.js"></script>
    <script src="js/jquery.timepicker.min.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/main.js"></script>

    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAwGUSnH2EpjrptUBcc473sdpjCghkuLu8&callback=initMap"
    async defer></script>
    <script src="js/jquery.fancybox.pack.js"></script>
<script src="js/jquery.fancybox-media.js"></script>
<script src="js/owl.js"></script>
<script src="js/wow.js"></script>
<script src="js/appear.js"></script>
<script src="js/color-settings.js"></script>


    <script src="js/bootstrap.js"></script>
    <script src="js/jquery.js.js"></script>
    <script
      defer
      src="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"
    ></script>
    <script>
    const element =  document.querySelector('.my-element')
element.classList.add('animated', 'bounceOutLeft')
</script>
  </body>
</html>
